#!/bin/sh
export DISPLAY=:0
cd /usr/share/auxmenu
python auxmenu.py &

exit 1
